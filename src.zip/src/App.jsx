import { useEffect, useMemo, useRef, useState } from 'react'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'

import TransactionForm from './components/TransactionForm'
import TransactionList from './components/TransactionList'
import Summary from './components/Summary'
import PieChart from './components/PieChart'
import LineChart from './components/LineChart'
import PrivacyPolicy from './components/PrivacyPolicy'
import CurrencySelector from './components/CurrencySelector'
import BudgetManager from './components/BudgetManager'
import YearComparison from './components/YearComparison'

const getMonthRangeFromDate = (date) => {
  const start = new Date(date.getFullYear(), date.getMonth(), 1)
  start.setHours(0, 0, 0, 0)

  const end = new Date(date.getFullYear(), date.getMonth() + 1, 1)
  end.setMilliseconds(-1)

  return { start, end }
}

const getYearRangeFromDate = (date) => {
  const year = date.getFullYear()

  const start = new Date(year, 0, 1)
  start.setHours(0, 0, 0, 0)

  const end = new Date(year + 1, 0, 1)
  end.setMilliseconds(-1)

  return { start, end }
}

const getPeriodLabel = (mode, date) => {
  if (mode === 'month') {
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
  }
  if (mode === 'year') {
    return date.getFullYear().toString()
  }
  return ''
}

function DebugOverlay({ comparisonMode, currentPeriod, previousPeriod, transactions }) {
  const [isVisible, setIsVisible] = useState(false)

  if (import.meta.env.PROD) return null

  const countInRange = (range) =>
    !range
      ? 0
      : transactions.filter((t) => {
          const d = new Date(t.date)
          return d >= range.start && d <= range.end
        }).length

  return (
    <>
      <button
        onClick={() => setIsVisible((v) => !v)}
        className="fixed bottom-4 right-4 z-50 w-10 h-10 bg-violet-600 text-white rounded-full"
        title="Toggle debug overlay"
      >
        ⚙
      </button>

      {isVisible && (
        <div className="fixed bottom-16 right-4 z-50 w-80 bg-neutral-900 border border-neutral-700 rounded-xl p-4 text-xs font-mono">
          <div className="text-violet-400 mb-2">Debug</div>
          <div>Mode: {comparisonMode}</div>
          <div>Current: {countInRange(currentPeriod)}</div>
          <div>Previous: {countInRange(previousPeriod)}</div>
          <div>Total: {transactions.length}</div>
        </div>
      )}
    </>
  )
}

function Dashboard() {
  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem('transactions')
    return saved ? JSON.parse(saved) : []
  })

  const [budgets, setBudgets] = useState(() => {
    const saved = localStorage.getItem('budgets')
    return saved ? JSON.parse(saved) : {}
  })

  const [comparisonMode, setComparisonMode] = useState('none')
  const [focusedCategory, setFocusedCategory] = useState(null)
  const [viewDate, setViewDate] = useState(new Date())
  const [hoveredTransaction, setHoveredTransaction] = useState(null)

  // NEW: fit mode to reduce in-component scrolling
  const [fitMode, setFitMode] = useState(true)

  const [showNav, setShowNav] = useState(false)
  const chartsRef = useRef(null)
  const transactionsRef = useRef(null)

  useEffect(() => {
    localStorage.setItem('transactions', JSON.stringify(transactions))
  }, [transactions])

  useEffect(() => {
    localStorage.setItem('budgets', JSON.stringify(budgets))
  }, [budgets])

  const currentPeriod = useMemo(() => {
    if (comparisonMode === 'year') return getYearRangeFromDate(viewDate)
    if (comparisonMode === 'month') return getMonthRangeFromDate(viewDate)
    return null
  }, [comparisonMode, viewDate])

  const previousPeriod = useMemo(() => {
    if (comparisonMode === 'month') {
      const prev = new Date(viewDate)
      prev.setMonth(prev.getMonth() - 1)
      return getMonthRangeFromDate(prev)
    }

    if (comparisonMode === 'year') {
      const prev = new Date(viewDate)
      prev.setFullYear(prev.getFullYear() - 1)
      return getYearRangeFromDate(prev)
    }

    return null
  }, [comparisonMode, viewDate])

  const periodLabel = getPeriodLabel(comparisonMode, viewDate)

  const addTransaction = (t) => setTransactions([t, ...transactions])

  const deleteTransaction = (id) =>
    setTransactions(transactions.filter((t) => t.id !== id))

  const editTransaction = (id, updated) =>
    setTransactions(transactions.map((t) => (t.id === id ? { ...updated, id } : t)))

  const exportToCSV = () => {
    if (!transactions.length) return alert('No transactions')

    const rows = transactions.map((t) => [
      new Date(t.date).toLocaleDateString(),
      t.description,
      t.category,
      t.type,
      Number(t.amount).toFixed(2),
    ])

    const csv = [
      ['Date', 'Description', 'Category', 'Type', 'Amount'].join(','),
      ...rows.map((r) => r.join(',')),
    ].join('\n')

    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'transactions.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  const goPrev = () => {
    setViewDate((d) => {
      if (comparisonMode === 'year') return new Date(d.getFullYear() - 1, 0, 1)
      return new Date(d.getFullYear(), d.getMonth() - 1, 1)
    })
  }

  const goNext = () => {
    setViewDate((d) => {
      if (comparisonMode === 'year') return new Date(d.getFullYear() + 1, 0, 1)
      return new Date(d.getFullYear(), d.getMonth() + 1, 1)
    })
  }

  const scrollToRef = (ref) => {
    ref?.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  useEffect(() => {
    const onScroll = () => setShowNav(window.scrollY > 500)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <div className="min-h-screen bg-neutral-950 p-4 sm:p-6 lg:p-10">
      <div className="max-w-7xl mx-auto">
        <header className="mb-10 text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-white mb-2">
            Finance
          </h1>
          <p className="text-neutral-400">Track your income and expenses</p>

          <div className="flex flex-col sm:flex-row justify-center items-center gap-3 mt-6">
            <CurrencySelector />
            {transactions.length > 0 && (
              <button
                onClick={exportToCSV}
                className="px-5 py-2.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-white text-sm font-medium transition-colors"
              >
                Export CSV
              </button>
            )}
          </div>
        </header>

        <section className="mb-10">
          <Summary transactions={transactions} />
        </section>

        <section className="mb-6 flex flex-col items-center gap-3">
          <div className="bg-neutral-800 rounded-full p-1 flex gap-1 text-sm">
            {['none', 'month', 'year'].map((mode) => (
              <button
                key={mode}
                onClick={() => setComparisonMode(mode)}
                className={`px-4 py-1.5 rounded-full transition-colors ${
                  comparisonMode === mode ? 'bg-white text-black' : 'text-neutral-300 hover:text-white'
                }`}
              >
                {mode === 'none' ? 'No Comparison' : mode}
              </button>
            ))}
          </div>

          {comparisonMode !== 'none' && (
            <div className="flex items-center gap-4 text-sm text-neutral-300">
              <button onClick={goPrev} className="hover:text-white transition-colors" aria-label="Previous">
                ←
              </button>
              <span className="text-neutral-400">{periodLabel}</span>
              <button onClick={goNext} className="hover:text-white transition-colors" aria-label="Next">
                →
              </button>
            </div>
          )}

          {/* NEW: Fit toggle */}
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <button
              onClick={() => setFitMode((v) => !v)}
              className={`px-3 py-1.5 rounded-full transition-colors ${
                fitMode ? 'bg-neutral-200 text-black' : 'bg-neutral-800 text-neutral-300 hover:text-white'
              }`}
            >
              Fit charts to screen
            </button>
            <span className="hidden sm:inline">
              When enabled, chart cards keep their content visible without requiring intra-card scrolling
            </span>
          </div>
        </section>

        {/* Charts */}
        <section
          ref={chartsRef}
          className={`grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 mb-12 ${
            fitMode ? 'lg:items-stretch' : ''
          }`}
        >
          <PieChart
            transactions={transactions}
            currentPeriod={currentPeriod}
            previousPeriod={previousPeriod}
            onCategoryFocus={setFocusedCategory}
            hoveredTransaction={hoveredTransaction}
            fitHeight={fitMode} // NEW: hint to card layout
          />

          <LineChart
            transactions={transactions}
            currentPeriod={currentPeriod}
            focusedCategory={focusedCategory}
            hoveredTransaction={hoveredTransaction}
            fitHeight={fitMode} // NEW: hint to card layout
          />
        </section>

        <section className="mb-12">
          <BudgetManager
            budgets={budgets}
            setBudgets={setBudgets}
            transactions={transactions}
            currentPeriod={currentPeriod}
            focusedCategory={focusedCategory}
          />
        </section>

        <YearComparison transactions={transactions} />

        {/* Transactions */}
        <section ref={transactionsRef} className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-12">
          <TransactionForm onAddTransaction={addTransaction} />
          <TransactionList
            transactions={transactions}
            onDeleteTransaction={deleteTransaction}
            onEditTransaction={editTransaction}
            onHoverCategory={setFocusedCategory}
            onHoverTransaction={setHoveredTransaction}
            currentPeriod={currentPeriod}
          />
        </section>
      </div>

      {showNav && (
        <div className="fixed bottom-4 right-4 z-40 flex flex-col gap-2">
          <button
            onClick={() => scrollToRef(chartsRef)}
            className="px-4 py-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-white text-sm shadow-lg transition-colors"
            title="Jump to charts"
          >
            Charts
          </button>
          <button
            onClick={() => scrollToRef(transactionsRef)}
            className="px-4 py-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-white text-sm shadow-lg transition-colors"
            title="Jump to transactions"
          >
            Transactions
          </button>
        </div>
      )}

      <DebugOverlay
        comparisonMode={comparisonMode}
        currentPeriod={currentPeriod}
        previousPeriod={previousPeriod}
        transactions={transactions}
      />
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-neutral-950">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
        </Routes>

        <footer className="py-10 text-center border-t border-neutral-800">
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/privacy" className="text-neutral-500 hover:text-white text-sm transition-colors">
              Privacy Policy
            </Link>
            <Link to="https://github.com/Crespo1301" className="text-neutral-500 hover:text-white text-sm transition-colors">
              GitHub Repository
            </Link>
            <Link
              to="https://www.linkedin.com/in/carlos-crespo-46608014a/"
              className="text-neutral-500 hover:text-white text-sm transition-colors"
            >
              LinkedIn Profile
            </Link>
          </div>

          <p className="mt-4 text-neutral-500 text-sm">
            © {new Date().getFullYear()} Carlos Crespo. All rights reserved.
          </p>
        </footer>
      </div>
    </BrowserRouter>
  )
}

export default App
