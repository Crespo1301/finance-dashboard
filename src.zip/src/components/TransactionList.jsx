import { useEffect, useMemo, useRef, useState } from 'react'
import { useCurrency } from '../context/CurrencyContext'

const CATEGORIES = [
  'Bills',
  'Credit Card',
  'Entertainment',
  'Food',
  'Housing',
  'Health',
  'Loans',
  'Transportation',
  'Utilities',
  'Shopping',
  'Income',
  'Other',
]

const safeLower = (v) => (typeof v === 'string' ? v.toLowerCase() : '')

const formatShortDate = (iso) => {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

const formatFullDateTime = (iso) => {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  return d.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

const isInRange = (date, range) => {
  if (!range?.start || !range?.end) return true
  return date >= range.start && date <= range.end
}

const makeToastId = () => `${Date.now()}_${Math.random().toString(16).slice(2)}`

function TransactionList({
  transactions,
  onDeleteTransaction,
  onEditTransaction,
  onHoverCategory,
  onHoverTransaction, // optional: can be wired to chart hover sync later
  currentPeriod, // optional: enables "In current period" toggle
}) {
  const { formatAmount } = useCurrency()

  const [editingId, setEditingId] = useState(null)
  const [editForm, setEditForm] = useState({})

  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategory, setFilterCategory] = useState('All')
  const [filterType, setFilterType] = useState('All')

  const [sortKey, setSortKey] = useState('date') // date | amount | description
  const [sortDir, setSortDir] = useState('desc') // asc | desc

  const [showOnlyInPeriod, setShowOnlyInPeriod] = useState(false)

  const [expanded, setExpanded] = useState(() => new Set()) // ids and groupIds
  const [selected, setSelected] = useState(() => new Set()) // ids and group keys

  // Undo delete system
  const [pendingDeletes, setPendingDeletes] = useState([]) // { toastId, ids, label, timeoutAt }
  const pendingTimers = useRef(new Map()) // toastId -> timer

  const [optimisticallyHiddenIds, setOptimisticallyHiddenIds] = useState(() => new Set())

  useEffect(() => {
    return () => {
      pendingTimers.current.forEach((t) => clearTimeout(t))
      pendingTimers.current.clear()
    }
  }, [])

  const normalizedTransactions = useMemo(() => {
    const list = Array.isArray(transactions) ? transactions : []
    return list
      .filter((t) => t && t.id)
      .map((t) => ({
        ...t,
        _dateObj: new Date(t.date),
        _amountNum: Number(t.amount),
        _descLower: safeLower(t.description),
        _catLower: safeLower(t.category),
        _notesLower: safeLower(t.notes),
      }))
  }, [transactions])

  const visibleBaseTransactions = useMemo(() => {
    // Hide optimistically removed items while undo window is open
    if (!optimisticallyHiddenIds.size) return normalizedTransactions
    return normalizedTransactions.filter((t) => !optimisticallyHiddenIds.has(t.id))
  }, [normalizedTransactions, optimisticallyHiddenIds])

  const filteredTransactions = useMemo(() => {
    const term = safeLower(searchTerm).trim()

    return visibleBaseTransactions.filter((t) => {
      const matchesSearch =
        !term ||
        t._descLower.includes(term) ||
        t._catLower.includes(term) ||
        t._notesLower.includes(term) ||
        String(t.type || '').toLowerCase().includes(term) ||
        String(t.amount ?? '').includes(term)

      const matchesCategory = filterCategory === 'All' || t.category === filterCategory
      const matchesType = filterType === 'All' || t.type === filterType

      const matchesPeriod =
        !showOnlyInPeriod || !currentPeriod
          ? true
          : isInRange(t._dateObj, currentPeriod)

      return matchesSearch && matchesCategory && matchesType && matchesPeriod
    })
  }, [
    visibleBaseTransactions,
    searchTerm,
    filterCategory,
    filterType,
    showOnlyInPeriod,
    currentPeriod,
  ])

  // Group by groupId, but only if groupId exists
  const groupedRows = useMemo(() => {
    const groups = new Map() // groupId -> items
    const singles = []

    for (const t of filteredTransactions) {
      if (t.groupId) {
        if (!groups.has(t.groupId)) groups.set(t.groupId, [])
        groups.get(t.groupId).push(t)
      } else {
        singles.push(t)
      }
    }

    const rows = []

    // Build group rows
    for (const [groupId, items] of groups.entries()) {
      // Sort items by date then category for stable display
      const sortedItems = [...items].sort((a, b) => {
        const da = a._dateObj?.getTime() || 0
        const db = b._dateObj?.getTime() || 0
        if (da !== db) return db - da
        return String(a.category || '').localeCompare(String(b.category || ''))
      })

      const date = sortedItems[0]?.date
      const description = sortedItems[0]?.description || 'Grouped transaction'
      const type = sortedItems[0]?.type || 'expense'

      const total = sortedItems.reduce((acc, it) => acc + (Number(it._amountNum) || 0), 0)

      // Category summary
      const catCounts = sortedItems.reduce((acc, it) => {
        const c = it.category || 'Other'
        acc[c] = (acc[c] || 0) + 1
        return acc
      }, {})
      const topCats = Object.entries(catCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 2)
        .map(([c]) => c)

      rows.push({
        kind: 'group',
        key: `group:${groupId}`,
        groupId,
        date,
        description,
        type,
        amount: total,
        categories: topCats,
        items: sortedItems,
      })
    }

    // Build single rows
    for (const t of singles) {
      rows.push({
        kind: 'single',
        key: `tx:${t.id}`,
        tx: t,
      })
    }

    // Sorting at the row level
    const getRowDate = (r) => {
      const iso = r.kind === 'group' ? r.date : r.tx?.date
      const d = new Date(iso)
      return Number.isNaN(d.getTime()) ? 0 : d.getTime()
    }

    const getRowAmount = (r) => {
      const a = r.kind === 'group' ? r.amount : Number(r.tx?._amountNum || 0)
      return Number.isFinite(a) ? a : 0
    }

    const getRowDesc = (r) => {
      const s = r.kind === 'group' ? r.description : r.tx?.description
      return String(s || '')
    }

    const compare = (a, b) => {
      let v = 0
      if (sortKey === 'date') v = getRowDate(a) - getRowDate(b)
      if (sortKey === 'amount') v = getRowAmount(a) - getRowAmount(b)
      if (sortKey === 'description') v = getRowDesc(a).localeCompare(getRowDesc(b))

      return sortDir === 'asc' ? v : -v
    }

    rows.sort(compare)
    return rows
  }, [filteredTransactions, sortKey, sortDir])

  const totals = useMemo(() => {
    const income = filteredTransactions
      .filter((t) => t.type === 'income')
      .reduce((acc, t) => acc + (Number(t._amountNum) || 0), 0)

    const expense = filteredTransactions
      .filter((t) => t.type === 'expense')
      .reduce((acc, t) => acc + (Number(t._amountNum) || 0), 0)

    const net = income - expense
    return { income, expense, net }
  }, [filteredTransactions])

  const clearFilters = () => {
    setSearchTerm('')
    setFilterCategory('All')
    setFilterType('All')
    setShowOnlyInPeriod(false)
  }

  const toggleExpanded = (key) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  const toggleSelected = (key, checked) => {
    setSelected((prev) => {
      const next = new Set(prev)
      if (checked) next.add(key)
      else next.delete(key)
      return next
    })
  }

  const selectAllVisible = () => {
    setSelected(() => {
      const next = new Set()
      groupedRows.forEach((r) => next.add(r.key))
      return next
    })
  }

  const clearSelection = () => setSelected(new Set())

  const queueDelete = ({ ids, label }) => {
    if (!ids.length) return

    const toastId = makeToastId()
    const timeoutMs = 4500
    const timeoutAt = Date.now() + timeoutMs

    // Optimistically hide
    setOptimisticallyHiddenIds((prev) => {
      const next = new Set(prev)
      ids.forEach((id) => next.add(id))
      return next
    })

    // Create toast
    setPendingDeletes((prev) => [
      ...prev,
      { toastId, ids, label, timeoutAt },
    ])

    const timer = setTimeout(() => {
      // Commit delete
      ids.forEach((id) => onDeleteTransaction?.(id))

      // Remove toast and hidden ids
      setPendingDeletes((prev) => prev.filter((t) => t.toastId !== toastId))
      setOptimisticallyHiddenIds((prev) => {
        const next = new Set(prev)
        ids.forEach((id) => next.delete(id))
        return next
      })

      pendingTimers.current.delete(toastId)
    }, timeoutMs)

    pendingTimers.current.set(toastId, timer)
  }

  const undoDelete = (toastId) => {
    const toast = pendingDeletes.find((t) => t.toastId === toastId)
    if (!toast) return

    const timer = pendingTimers.current.get(toastId)
    if (timer) clearTimeout(timer)
    pendingTimers.current.delete(toastId)

    // Unhide
    setOptimisticallyHiddenIds((prev) => {
      const next = new Set(prev)
      toast.ids.forEach((id) => next.delete(id))
      return next
    })

    // Remove toast
    setPendingDeletes((prev) => prev.filter((t) => t.toastId !== toastId))
  }

  const deleteSingle = (tx) => {
    queueDelete({ ids: [tx.id], label: tx.description || 'Transaction' })
  }

  const deleteGroup = (groupId, items) => {
    const ids = items.map((t) => t.id)
    queueDelete({ ids, label: 'Group' })
  }

  const deleteSelected = () => {
    const ids = []
    let label = 'Selection'

    groupedRows.forEach((r) => {
      if (!selected.has(r.key)) return

      if (r.kind === 'single') {
        ids.push(r.tx.id)
      } else {
        r.items.forEach((t) => ids.push(t.id))
      }
    })

    // Deduplicate
    const uniq = Array.from(new Set(ids))
    if (!uniq.length) return

    queueDelete({ ids: uniq, label })
    clearSelection()
  }

  const beginEdit = (tx) => {
    setEditingId(tx.id)
    setEditForm({
      description: tx.description || '',
      amount: tx.amount,
      category: tx.category || 'Other',
    })
  }

  const saveEdit = (tx) => {
    const nextAmount = Number(editForm.amount)
    if (!Number.isFinite(nextAmount) || nextAmount <= 0) return

    onEditTransaction?.(tx.id, {
      ...tx,
      description: editForm.description,
      amount: nextAmount,
      category: editForm.category,
    })
    setEditingId(null)
  }

  const hasAnyTransactions = transactions.length > 0

  if (!hasAnyTransactions) {
    return (
      <div className="p-8 rounded-2xl bg-neutral-700 flex flex-col items-center justify-center min-h-[400px]">
        <div className="w-16 h-16 rounded-full bg-neutral-600 flex items-center justify-center mb-4">
          <svg className="w-8 h-8 text-neutral-200" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3v11.25A2.25 2.25 0 0 0 6 16.5h2.25M3.75 3h16.5m0 0v11.25A2.25 2.25 0 0 1 18 16.5h-2.25m-7.5 0h7.5m-7.5 0-1 3m8.5-3 1 3m0 0 .5 1.5m-.5-1.5h-9.5m0 0-.5 1.5" />
          </svg>
        </div>
        <h2 className="text-xl font-semibold text-neutral-200 mb-2">No Transactions Yet</h2>
        <p className="text-neutral-400 text-center text-sm">Start by adding your first transaction</p>
      </div>
    )
  }

  return (
    <div className="p-6 sm:p-8 rounded-2xl bg-neutral-700 relative">
      <div className="flex items-start justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-semibold text-neutral-200 tracking-tight">Transactions</h2>
          <div className="text-xs text-neutral-400 mt-1">
            Showing {filteredTransactions.length} of {transactions.length}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {selected.size > 0 && (
            <>
              <button
                onClick={deleteSelected}
                className="px-3 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-medium transition-colors"
              >
                Delete selected
              </button>
              <button
                onClick={clearSelection}
                className="px-3 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-600 text-neutral-200 text-sm font-medium transition-colors"
              >
                Clear selection
              </button>
            </>
          )}

          <span className="px-3 py-1 bg-neutral-500 text-neutral-200 text-xs font-medium rounded-full">
            {transactions.length}
          </span>
        </div>
      </div>

      {/* Summary strip */}
      <div className="grid grid-cols-3 gap-3 mb-6 text-sm">
        <div className="bg-neutral-800 rounded-xl p-3">
          <div className="text-xs text-neutral-400">Income</div>
          <div className="text-neutral-100 font-semibold tabular-nums">{formatAmount(totals.income)}</div>
        </div>
        <div className="bg-neutral-800 rounded-xl p-3">
          <div className="text-xs text-neutral-400">Expenses</div>
          <div className="text-neutral-100 font-semibold tabular-nums">{formatAmount(totals.expense)}</div>
        </div>
        <div className="bg-neutral-800 rounded-xl p-3">
          <div className="text-xs text-neutral-400">Net</div>
          <div className={`font-semibold tabular-nums ${totals.net >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {formatAmount(totals.net)}
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="mb-6 space-y-3">
        <div className="relative">
          <svg className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-neutral-600" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
          </svg>
          <input
            type="text"
            placeholder="Search description, category, notes, amount..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-11 pr-4 py-2.5 bg-neutral-200 border border-neutral-200 rounded-xl text-black text-sm placeholder-neutral-400 focus:outline-none focus:border-violet-500 transition-colors"
          />
        </div>

        <div className="flex gap-2 flex-wrap items-center">
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 bg-neutral-200 border border-neutral-200 rounded-lg text-neutral-900 text-sm appearance-none cursor-pointer focus:outline-none focus:border-violet-500 transition-colors"
          >
            <option value="All">All Types</option>
            <option value="income">Income</option>
            <option value="expense">Expense</option>
          </select>

          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-3 py-2 bg-neutral-200 border border-neutral-200 rounded-lg text-neutral-900 text-sm appearance-none cursor-pointer focus:outline-none focus:border-violet-500 transition-colors"
          >
            <option value="All">All Categories</option>
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          <div className="flex items-center gap-2 px-3 py-2 bg-neutral-800 rounded-lg">
            <span className="text-xs text-neutral-300">Sort</span>
            <select
              value={sortKey}
              onChange={(e) => setSortKey(e.target.value)}
              className="bg-neutral-800 text-neutral-100 text-sm focus:outline-none"
            >
              <option value="date">Date</option>
              <option value="amount">Amount</option>
              <option value="description">Description</option>
            </select>
            <button
              type="button"
              onClick={() => setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))}
              className="text-neutral-300 hover:text-white transition-colors"
              title="Toggle sort direction"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={1.8} viewBox="0 0 24 24">
                {sortDir === 'asc' ? (
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8 7l4-4 4 4M12 3v18" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16 17l-4 4-4-4M12 21V3" />
                )}
              </svg>
            </button>
          </div>

          {currentPeriod && (
            <button
              type="button"
              onClick={() => setShowOnlyInPeriod((v) => !v)}
              className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                showOnlyInPeriod ? 'bg-white text-black' : 'bg-neutral-800 text-neutral-200 hover:bg-neutral-600'
              }`}
              title="Show only transactions inside the current period"
            >
              In current period
            </button>
          )}

          {(searchTerm || filterCategory !== 'All' || filterType !== 'All' || showOnlyInPeriod) && (
            <button
              onClick={clearFilters}
              className="px-3 py-2 bg-neutral-200 hover:bg-neutral-400 rounded-lg text-neutral-900 text-sm font-medium transition-colors"
            >
              Clear
            </button>
          )}

          {groupedRows.length > 0 && (
            <button
              type="button"
              onClick={selectAllVisible}
              className="px-3 py-2 bg-neutral-800 hover:bg-neutral-600 rounded-lg text-neutral-200 text-sm font-medium transition-colors"
            >
              Select all visible
            </button>
          )}
        </div>
      </div>

      {/* Empty Filter Results */}
      {groupedRows.length === 0 ? (
        <div className="text-center py-10">
          <div className="w-12 h-12 rounded-full bg-neutral-600 flex items-center justify-center mx-auto mb-3">
            <svg className="w-6 h-6 text-neutral-200" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
            </svg>
          </div>
          <h3 className="text-base font-bold text-neutral-200 mb-1">No Results</h3>
          <p className="text-neutral-400 text-sm">Try adjusting your filters</p>
        </div>
      ) : (
        <div className="space-y-2 max-h-[560px] overflow-y-auto pr-1">
          {groupedRows.map((row) => {
            if (row.kind === 'single') {
              const t = row.tx
              const isEditing = editingId === t.id
              const isExpanded = expanded.has(row.key)
              const isSelected = selected.has(row.key)

              return (
                <div
                  key={row.key}
                  onMouseEnter={() => {
                    onHoverCategory?.(t.category)
                    onHoverTransaction?.(t)
                  }}
                  onMouseLeave={() => {
                    onHoverCategory?.(null)
                    onHoverTransaction?.(null)
                  }}
                  className="group bg-neutral-200 rounded-xl transition-all duration-200 hover:shadow-sm"
                >
                  <div className="flex items-center gap-3 p-4">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={(e) => toggleSelected(row.key, e.target.checked)}
                      className="h-4 w-4 accent-violet-600"
                      aria-label="Select transaction"
                    />

                    <button
                      type="button"
                      onClick={() => toggleExpanded(row.key)}
                      className="p-2 rounded-lg text-neutral-700 hover:bg-neutral-300 transition-colors"
                      aria-label="Toggle details"
                      title="Toggle details"
                    >
                      <svg className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>

                    {isEditing ? (
                      <div className="flex-1 space-y-3">
                        <input
                          type="text"
                          value={editForm.description}
                          onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                          className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-black text-sm focus:outline-none focus:border-violet-500"
                          placeholder="Description"
                        />
                        <div className="flex gap-2">
                          <input
                            type="number"
                            value={editForm.amount}
                            onChange={(e) => setEditForm({ ...editForm, amount: e.target.value })}
                            className="flex-1 px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-black text-sm focus:outline-none focus:border-violet-500"
                            placeholder="Amount"
                            step="0.01"
                          />
                          <select
                            value={editForm.category}
                            onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                            className="px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-black text-sm focus:outline-none focus:border-violet-500"
                          >
                            {CATEGORIES.map((cat) => (
                              <option key={cat} value={cat}>{cat}</option>
                            ))}
                          </select>
                        </div>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => saveEdit(t)}
                            className="flex-1 py-2 bg-black text-white text-sm font-medium rounded-lg hover:bg-neutral-800 transition-colors"
                          >
                            Save
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            className="flex-1 py-2 bg-neutral-200 text-black text-sm font-medium rounded-lg hover:bg-neutral-300 transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-black truncate">{t.description}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs px-2 py-0.5 bg-neutral-300 text-neutral-800 rounded-full">
                              {t.category}
                            </span>
                            <span className="text-xs text-neutral-500">
                              {formatShortDate(t.date)}
                            </span>
                            {t.groupId && (
                              <span className="text-xs px-2 py-0.5 bg-neutral-300 text-neutral-700 rounded-full">
                                Grouped
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <span
                            className={`font-semibold tabular-nums ${
                              t.type === 'income' ? 'text-black' : 'text-neutral-600'
                            }`}
                          >
                            {t.type === 'income' ? '+' : '-'}
                            {formatAmount(Number(t.amount) || 0)}
                          </span>

                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              type="button"
                              onClick={() => beginEdit(t)}
                              className="p-2 text-neutral-700 hover:text-violet-700 hover:bg-violet-200 rounded-lg transition-colors"
                              aria-label="Edit"
                              title="Edit"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125" />
                              </svg>
                            </button>

                            <button
                              type="button"
                              onClick={() => deleteSingle(t)}
                              className="p-2 text-neutral-700 hover:text-red-700 hover:bg-red-200 rounded-lg transition-colors"
                              aria-label="Delete"
                              title="Delete"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={1.8} viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
                              </svg>
                            </button>
                          </div>
                        </div>
                      </>
                    )}
                  </div>

                  {isExpanded && !isEditing && (
                    <div className="px-4 pb-4">
                      <div className="bg-neutral-100 rounded-xl p-3 text-sm text-neutral-800">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <div>
                            <div className="text-xs text-neutral-500">Date</div>
                            <div className="text-neutral-900">{formatFullDateTime(t.date)}</div>
                          </div>
                          <div>
                            <div className="text-xs text-neutral-500">Type</div>
                            <div className="text-neutral-900">{t.type}</div>
                          </div>

                          {t.notes && (
                            <div className="sm:col-span-2">
                              <div className="text-xs text-neutral-500">Notes</div>
                              <div className="text-neutral-900 whitespace-pre-wrap">{t.notes}</div>
                            </div>
                          )}

                          {t.receipt?.name && (
                            <div className="sm:col-span-2">
                              <div className="text-xs text-neutral-500">Receipt</div>
                              <div className="text-neutral-900">{t.receipt.name}</div>
                            </div>
                          )}

                          {(t.groupId || t.id) && (
                            <div className="sm:col-span-2 flex items-center justify-between gap-3 mt-1">
                              <div className="text-xs text-neutral-500 truncate">
                                {t.groupId ? `Group ${t.groupId}` : ''}
                                {t.groupId ? ' · ' : ''}
                                {`Id ${t.id}`}
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  const text = t.groupId ? `${t.groupId}` : `${t.id}`
                                  navigator.clipboard?.writeText(text)
                                }}
                                className="text-xs px-2 py-1 rounded-lg bg-neutral-200 hover:bg-neutral-300 transition-colors"
                                title="Copy id"
                              >
                                Copy
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )
            }

            // Group row
            const isExpanded = expanded.has(row.key)
            const isSelected = selected.has(row.key)

            return (
              <div
                key={row.key}
                onMouseEnter={() => {
                  // Hover sync for groups: use the first item’s category as a hint
                  const first = row.items[0]
                  onHoverCategory?.(first?.category || null)
                  onHoverTransaction?.(first || null)
                }}
                onMouseLeave={() => {
                  onHoverCategory?.(null)
                  onHoverTransaction?.(null)
                }}
                className="group bg-neutral-200 rounded-xl transition-all duration-200 hover:shadow-sm"
              >
                <div className="flex items-center gap-3 p-4">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={(e) => toggleSelected(row.key, e.target.checked)}
                    className="h-4 w-4 accent-violet-600"
                    aria-label="Select group"
                  />

                  <button
                    type="button"
                    onClick={() => toggleExpanded(row.key)}
                    className="p-2 rounded-lg text-neutral-700 hover:bg-neutral-300 transition-colors"
                    aria-label="Toggle group details"
                    title="Toggle group details"
                  >
                    <svg className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>

                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-black truncate">{row.description}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs px-2 py-0.5 bg-neutral-300 text-neutral-800 rounded-full">
                        {row.categories.length ? row.categories.join(', ') : 'Grouped'}
                      </span>
                      <span className="text-xs text-neutral-500">{formatShortDate(row.date)}</span>
                      <span className="text-xs px-2 py-0.5 bg-neutral-300 text-neutral-700 rounded-full">
                        {row.items.length} items
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`font-semibold tabular-nums ${row.type === 'income' ? 'text-black' : 'text-neutral-600'}`}>
                      {row.type === 'income' ? '+' : '-'}
                      {formatAmount(Number(row.amount) || 0)}
                    </span>

                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        type="button"
                        onClick={() => deleteGroup(row.groupId, row.items)}
                        className="p-2 text-neutral-700 hover:text-red-700 hover:bg-red-200 rounded-lg transition-colors"
                        aria-label="Delete group"
                        title="Delete group"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={1.8} viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>

                {isExpanded && (
                  <div className="px-4 pb-4">
                    <div className="bg-neutral-100 rounded-xl p-3">
                      <div className="text-xs text-neutral-500 mb-2">
                        Group id {row.groupId}
                      </div>

                      <div className="space-y-2">
                        {row.items.map((t) => (
                          <div
                            key={t.id}
                            className="flex items-center justify-between gap-3 bg-neutral-200 rounded-lg px-3 py-2"
                          >
                            <div className="min-w-0">
                              <div className="text-sm text-neutral-900 truncate">{t.category}</div>
                              <div className="text-xs text-neutral-600">{formatFullDateTime(t.date)}</div>
                              {t.notes && (
                                <div className="text-xs text-neutral-700 mt-1 truncate">
                                  Notes {t.notes}
                                </div>
                              )}
                            </div>

                            <div className="flex items-center gap-2">
                              <div className="text-sm font-semibold text-neutral-800 tabular-nums">
                                {t.type === 'income' ? '+' : '-'}
                                {formatAmount(Number(t.amount) || 0)}
                              </div>

                              <button
                                type="button"
                                onClick={() => beginEdit(t)}
                                className="p-2 rounded-lg text-neutral-700 hover:text-violet-700 hover:bg-violet-200 transition-colors"
                                title="Edit item"
                              >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125" />
                                </svg>
                              </button>

                              <button
                                type="button"
                                onClick={() => deleteSingle(t)}
                                className="p-2 rounded-lg text-neutral-700 hover:text-red-700 hover:bg-red-200 transition-colors"
                                title="Delete item"
                              >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={1.8} viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
                                </svg>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="text-xs text-neutral-500 mt-3">
                        Group items are editable individually. Deleting the group deletes every item in the group.
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}

      {/* Undo toast stack */}
      {pendingDeletes.length > 0 && (
        <div className="fixed bottom-4 left-4 z-50 space-y-2">
          {pendingDeletes.slice(-3).map((t) => (
            <div key={t.toastId} className="bg-neutral-900 border border-neutral-700 rounded-xl shadow-xl px-4 py-3 w-[320px]">
              <div className="text-sm text-neutral-200">
                Deleted {t.label}
              </div>
              <div className="flex items-center justify-between mt-2">
                <div className="text-xs text-neutral-500">
                  Undo available briefly
                </div>
                <button
                  type="button"
                  onClick={() => undoDelete(t.toastId)}
                  className="px-3 py-1.5 rounded-lg bg-white text-black text-sm font-medium hover:bg-neutral-200 transition-colors"
                >
                  Undo
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default TransactionList
