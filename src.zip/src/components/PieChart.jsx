import { useMemo, useState } from 'react'
import { Pie } from 'react-chartjs-2'
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js'
import { useCurrency } from '../context/CurrencyContext'

ChartJS.register(ArcElement, Tooltip, Legend)

const COLORS = [
  '#38bdf8',
  '#22c55e',
  '#f472b6',
  '#facc15',
  '#a78bfa',
  '#fb7185',
  '#34d399',
  '#60a5fa',
]

const OTHER_THRESHOLD = 0.05

function PieChart({
  transactions = [],
  currentPeriod,
  previousPeriod,
  cutout = '65%',
  onCategoryFocus,
  hoveredTransaction,
  fitHeight = false,
}) {
  const { formatAmount } = useCurrency()
  const [activeCategory, setActiveCategory] = useState(null)
  const [hidden, setHidden] = useState({})

  const inRangeSafe = (date, range) => {
    if (!range?.start || !range?.end) return true
    return date >= range.start && date <= range.end
  }

  const aggregate = (txs) =>
    txs.reduce((acc, t) => {
      const cat = t.category || 'Other'
      acc[cat] = (acc[cat] || 0) + Number(t.amount || 0)
      return acc
    }, {})

  const allExpenses = useMemo(
    () => transactions.filter((t) => t.type === 'expense'),
    [transactions]
  )

  const periodExpenses = useMemo(() => {
    return allExpenses.filter((t) => inRangeSafe(new Date(t.date), currentPeriod))
  }, [allExpenses, currentPeriod])

  const currentExpenses = periodExpenses.length > 0 ? periodExpenses : allExpenses
  const showingFallbackAllTime = Boolean(currentPeriod && periodExpenses.length === 0 && allExpenses.length > 0)

  if (!currentExpenses.length) {
    return (
      <div className="p-8 rounded-2xl bg-neutral-800 text-neutral-400">
        No expense data available
      </div>
    )
  }

  const currentTotals = useMemo(() => aggregate(currentExpenses), [currentExpenses])

  const previousExpenses = useMemo(() => {
    if (!previousPeriod) return []
    return allExpenses.filter((t) => inRangeSafe(new Date(t.date), previousPeriod))
  }, [allExpenses, previousPeriod])

  const previousTotals = useMemo(() => aggregate(previousExpenses), [previousExpenses])

  const totalCurrent = useMemo(
    () => Object.values(currentTotals).reduce((a, b) => a + b, 0),
    [currentTotals]
  )

  const grouped = useMemo(() => {
    const g = {}
    let other = 0
    Object.entries(currentTotals).forEach(([cat, value]) => {
      if (totalCurrent > 0 && value / totalCurrent < OTHER_THRESHOLD) other += value
      else g[cat] = value
    })
    if (other > 0) g.Other = other
    return g
  }, [currentTotals, totalCurrent])

  const entries = useMemo(() => Object.entries(grouped).sort((a, b) => b[1] - a[1]), [grouped])
  const labels = useMemo(() => entries.map(([l]) => l), [entries])
  const values = useMemo(() => entries.map(([, v]) => v), [entries])

  const deltas = useMemo(() => {
    if (!previousExpenses.length) return {}
    return labels.reduce((acc, label) => {
      const prev = previousTotals[label] || 0
      const curr = currentTotals[label] || 0
      acc[label] = prev === 0 ? null : ((curr - prev) / prev) * 100
      return acc
    }, {})
  }, [labels, previousExpenses.length, previousTotals, currentTotals])

  const hoveredCategory = useMemo(() => {
    const cat = hoveredTransaction?.category
    if (!cat) return null
    if (grouped[cat] != null) return cat
    if (grouped.Other != null) return 'Other'
    return null
  }, [hoveredTransaction, grouped])

  const effectiveFocus = activeCategory || hoveredCategory

  const displayValues = useMemo(() => {
    return labels.map((label, i) => {
      if (hidden[label]) return 0
      if (effectiveFocus && effectiveFocus !== label) return values[i] * 0.15
      return values[i]
    })
  }, [labels, values, hidden, effectiveFocus])

  const backgroundColors = useMemo(() => {
    return labels.map((label, i) => {
      if (effectiveFocus && effectiveFocus !== label) return 'rgba(255,255,255,0.08)'
      return COLORS[i % COLORS.length]
    })
  }, [labels, effectiveFocus])

  const borderColors = useMemo(() => {
    return labels.map((label) => {
      if (hoveredCategory && label === hoveredCategory) return '#ffffff'
      const delta = deltas[label]
      if (delta == null) return '#0f172a'
      return delta >= 0 ? '#22c55e' : '#ef4444'
    })
  }, [labels, deltas, hoveredCategory])

  const borderWidths = useMemo(() => {
    return labels.map((label) => (hoveredCategory && label === hoveredCategory ? 3 : 2))
  }, [labels, hoveredCategory])

  const data = useMemo(() => {
    return {
      labels,
      datasets: [
        {
          data: displayValues,
          backgroundColor: backgroundColors,
          borderColor: borderColors,
          borderWidth: borderWidths,
          hoverOffset: 16,
          cutout,
        },
      ],
    }
  }, [labels, displayValues, backgroundColors, borderColors, borderWidths, cutout])

  const options = useMemo(() => {
    return {
      responsive: true,
      maintainAspectRatio: false, // KEY for fixed height layouts
      animation: { duration: 700, easing: 'easeOutQuart' },
      onClick: (_, elements) => {
        if (!elements.length) {
          setActiveCategory(null)
          onCategoryFocus?.(null)
          return
        }
        const label = labels[elements[0].index]
        const next = activeCategory === label ? null : label
        setActiveCategory(next)
        onCategoryFocus?.(next)
      },
      plugins: {
        legend: {
          position: 'bottom',
          onClick: (_, item) => {
            const label = item.text
            setHidden((p) => ({ ...p, [label]: !p[label] }))
          },
          labels: {
            color: '#e5e7eb',
            padding: 16,
            usePointStyle: true,
          },
        },
        tooltip: {
          backgroundColor: '#020617',
          padding: 12,
          callbacks: {
            label: (ctx) => {
              const label = ctx.label
              const value = values[ctx.dataIndex]
              const delta = deltas[label]
              return delta != null
                ? `${label}: ${formatAmount(value)} (${delta >= 0 ? '▲' : '▼'} ${Math.abs(delta).toFixed(1)}%)`
                : `${label}: ${formatAmount(value)}`
            },
          },
        },
      },
    }
  }, [labels, activeCategory, onCategoryFocus, values, deltas, formatAmount])

  const centerLabel = effectiveFocus || 'Total'
  const centerValue = effectiveFocus ? grouped[effectiveFocus] : totalCurrent
  const centerDelta = effectiveFocus && deltas[effectiveFocus] != null ? deltas[effectiveFocus] : null

  return (
    <div className={`p-6 sm:p-8 rounded-2xl bg-neutral-800 space-y-5 ${fitHeight ? 'flex flex-col' : ''}`}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold text-neutral-200">Expense Breakdown</h2>
          <div className="text-xs text-neutral-500 mt-1">
            {showingFallbackAllTime ? 'Showing all-time expenses (no data for selected period)' : 'Showing expenses for selected period'}
          </div>
        </div>

        {effectiveFocus && (
          <button
            type="button"
            onClick={() => {
              setActiveCategory(null)
              onCategoryFocus?.(null)
            }}
            className="text-xs px-3 py-1.5 rounded-full bg-neutral-900 text-neutral-200 hover:bg-neutral-700 transition-colors"
            title="Clear focus"
          >
            Clear focus
          </button>
        )}
      </div>

      <div className={fitHeight ? 'flex-1 min-h-0' : ''}>
        <div className={`relative ${fitHeight ? 'h-[340px] sm:h-[360px]' : 'h-[360px]'}`}>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-sm text-neutral-400">{centerLabel}</span>
            <span className="text-lg font-semibold text-neutral-200">{formatAmount(centerValue || 0)}</span>
            {centerDelta != null && (
              <span className={`text-xs mt-1 ${centerDelta >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {centerDelta >= 0 ? '▲' : '▼'} {Math.abs(centerDelta).toFixed(1)}%
              </span>
            )}
          </div>

          <Pie data={data} options={options} />
        </div>
      </div>

      <div className="text-xs text-neutral-500">
        Comparison auto-disables when no data exists for the selected period
      </div>
    </div>
  )
}

export default PieChart
